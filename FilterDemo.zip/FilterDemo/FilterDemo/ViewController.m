//
//  ViewController.m
//  FilterDemo
//
//  Created by CaoFeng on 2017/6/5.
//  Copyright © 2017年 深圳中业兴融互联网金融服务有限公司. All rights reserved.
//

#import "ViewController.h"
#import <Accelerate/Accelerate.h>
#import "GPUImage.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    /*********滤镜效果的几种方法,基本用法*************/
    
    UIImageView *originImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"1.jpg"]];
    
    originImage.frame = CGRectMake(70, 100, 300, 400);
    
    [self.view addSubview:originImage];
    
    
    
    /******以下使用起来较简单的方法，不过滤镜效果也有限*****/
    
    //  1.针对iOS8之前使用滤镜
    
    /*
    UIToolbar *toolBar1 = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 150, 400)];
    toolBar1.barStyle = UIBarStyleDefault;
    [originImage addSubview:toolBar1];
    */
    
    //  2.针对iOS8之后使用滤镜，也是苹果官方比较推荐的用法，效率很高，UIBlurEffect
    
    /*
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    
    UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
    effectView.frame = CGRectMake(0, 0, originImage.frame.size.width * 0.5, originImage.frame.size.height);
    [originImage addSubview:effectView];
    */
    
    /***********8以下三种用起来比较复杂的方法，不过滤镜效果异常丰富********/
    
    //3. 使用vImage 实现滤镜效果，需要库 <Accelerate/Accelerate.h>
    /*
     originImage.image = [self blurryImage:originImage.image withBlurLevel:0.5];
    */
    
    
    //4. 使用CIFilter实现滤镜效果，用起来也容易，易控制效果,用这个做项目基本没问题
   // originImage.image = [self filterImage:originImage.image];
    
    
    //5.使用GPUImage实现滤镜效果,这是一个第三方库，可以对直播视频进行美化，也是屌爆了，详情 https://github.com/BradLarson/GPUImage
    
    originImage.image = [self gpuImage:originImage.image];
    
    
}

/**
 *  使用vImage API进行图像的模糊处理
 *
 *  @param image 原图像
 *  @param blur  模糊度（0.0~1.0）
 *
 *  @return 模糊处理之后的图像
 */
- (UIImage *)blurryImage:(UIImage *)image withBlurLevel:(CGFloat)blur {
    if (blur < 0.f || blur > 1.f) {
        blur = 0.5f;
    }//判断曝光度
    int boxSize = (int)(blur * 100);//放大100，就是小数点之后两位有效
    boxSize = boxSize - (boxSize % 2) + 1;//如果是偶数，+1，变奇数
    
    CGImageRef img = image.CGImage;//获取图片指针
    
    vImage_Buffer inBuffer, outBuffer;//获取缓冲区
    vImage_Error error;
    
    void *pixelBuffer;
    
    CGDataProviderRef inProvider = CGImageGetDataProvider(img);//放回一个图片供应者信息
    CFDataRef inBitmapData = CGDataProviderCopyData(inProvider);//拷贝数据，并转化
    
    inBuffer.width = CGImageGetWidth(img);//放回位图的宽度
    inBuffer.height = CGImageGetHeight(img);//放回位图的高度
    inBuffer.rowBytes = CGImageGetBytesPerRow(img);//放回位图的
    
    inBuffer.data = (void*)CFDataGetBytePtr(inBitmapData);//填写图片信息
    
    pixelBuffer = malloc(CGImageGetBytesPerRow(img) *
                         CGImageGetHeight(img));//创建一个空间
    
    if(pixelBuffer == NULL)
        NSLog(@"No pixelbuffer");
    
    outBuffer.data = pixelBuffer;
    outBuffer.width = CGImageGetWidth(img);
    outBuffer.height = CGImageGetHeight(img);
    outBuffer.rowBytes = CGImageGetBytesPerRow(img);
    
    error = vImageBoxConvolve_ARGB8888(&inBuffer,
                                       &outBuffer,
                                       NULL,
                                       0,
                                       0,
                                       boxSize,//这个数一定要是奇数的，因此我们一开始的时候需要转化
                                       boxSize,//这个数一定要是奇数的，因此我们一开始的时候需要转化
                                       NULL,
                                       kvImageEdgeExtend);
    
    
    if (error) {
        NSLog(@"error from convolution %ld", error);
    }
    
    //将刚刚得出的数据，画出来。
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef ctx = CGBitmapContextCreate(
                                             outBuffer.data,
                                             outBuffer.width,
                                             outBuffer.height,
                                             8,
                                             outBuffer.rowBytes,
                                             colorSpace,
                                             kCGImageAlphaNoneSkipLast);
    CGImageRef imageRef = CGBitmapContextCreateImage (ctx);
    UIImage *returnImage = [UIImage imageWithCGImage:imageRef];
    
    //clean up
    CGContextRelease(ctx);
    CGColorSpaceRelease(colorSpace);
    
    free(pixelBuffer);
    CFRelease(inBitmapData);
    
    CGColorSpaceRelease(colorSpace);
    CGImageRelease(imageRef);
    
    return returnImage;
}

/**
 *  使用CIFilter API进行图像的模糊处理,炫酷
 *
 *  @param image 原图像
 *
 *  @return 模糊处理之后的图像
 */

- (UIImage *)filterImage:(UIImage *)image {
    
    //https://developer.apple.com/library/content/documentation/GraphicsImaging/Reference/CoreImageFilterReference/#//apple_ref/doc/uid/TP30000136-SW29
    
    CIImage *oldImg = [[CIImage alloc] initWithImage:image];
    
    // 设置name，可有多种滤镜效果,简直屌爆
    
    CIFilter *filter = [CIFilter filterWithName:@"CIGammaAdjust" keysAndValues:@"inputImage",oldImg, nil];
    
    [filter setValue:@(0.3) forKey:@"inputPower"];
    
    //输出图片
    CIImage *outputImage = [filter outputImage];
    //绘制
    CIContext *context = [CIContext contextWithOptions: nil];
    CGImageRef cgimg = [context createCGImage:outputImage fromRect:[outputImage extent]];
    UIImage *newImg = [UIImage imageWithCGImage:cgimg];
    
    return newImg;
    
}

/**
 *  使用GPUImage API进行图像的模糊处理,炫酷
 *
 *  @param image 原图像
 *
 *  @return 模糊处理之后的图像
 */

- (UIImage *)gpuImage:(UIImage *)image {
    
    GPUImagePicture *stillImageSource = [[GPUImagePicture alloc] initWithImage:image];
    GPUImageSepiaFilter *stillImageFilter = [[GPUImageSepiaFilter alloc] init];
    
    [stillImageSource addTarget:stillImageFilter];
    [stillImageFilter useNextFrameForImageCapture];
    [stillImageSource processImage];
    
    UIImage *currentFilteredVideoFrame = [stillImageFilter imageFromCurrentFramebuffer];
    
    return currentFilteredVideoFrame;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
